class ZendeskAppsTools::Server
    get '/' do
      "Hello World"
    end
  end
